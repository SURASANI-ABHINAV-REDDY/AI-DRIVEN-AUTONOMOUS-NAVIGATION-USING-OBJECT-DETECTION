# 300 > 2025-02-12 11:57pm
https://universe.roboflow.com/yolo-v8-image-labeling/300-aahdt

Provided by a Roboflow user
License: CC BY 4.0

